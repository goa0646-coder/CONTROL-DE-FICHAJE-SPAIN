<?php
// Necesidades por turno y puesto, cobertura (huecos) y generador de cuadrantes.
// El generador solo propone: lo que guarda pasa siempre por comprobar_plan().

function puestos(PDO $db): array
{
    return $db->query('SELECT id, nombre FROM puestos WHERE activo = 1 ORDER BY nombre')->fetchAll(PDO::FETCH_KEY_PAIR);
}

// [usuario_id => [puesto_id, …]]
function puestos_por_persona(PDO $db): array
{
    $out = [];
    foreach ($db->query('SELECT usuario_id, puesto_id FROM usuarios_puestos') as $x) $out[$x['usuario_id']][] = (int)$x['puesto_id'];
    return $out;
}

// Necesidades de un día: [[horario_id, puesto_id|null, personas], …]. Las de un día concreto sustituyen a las de «todos los días».
function necesidades_dia(PDO $db, string $fecha, ?int $centro = null): array
{
    $todas = consulta($db, 'SELECT * FROM necesidades WHERE activo = 1 AND (desde IS NULL OR desde <= ?) AND (hasta IS NULL OR hasta >= ?)', [$fecha, $fecha])->fetchAll();
    $n = (int)date('N', strtotime($fecha));
    $festivo = fn($c) => (bool)consulta($db, 'SELECT 1 FROM festivos WHERE fecha = ? AND (centro_id IS NULL OR centro_id = ?)', [$fecha, $c])->fetchColumn();
    $out = [];
    foreach ($todas as $x) {
        if ($centro && $x['centro_id'] && $x['centro_id'] != $centro) continue;
        if (!$x['festivos'] && $festivo($x['centro_id'] ?? $centro)) continue; // regla que no se aplica en festivos
        if ($x['dia'] && $x['dia'] != $n) continue;
        $clave = $x['horario_id'] . ':' . ($x['puesto_id'] ?? '');
        if (!isset($out[$clave]) || $x['dia']) $out[$clave] = [(int)$x['horario_id'], $x['puesto_id'] ? (int)$x['puesto_id'] : null, (int)$x['personas']];
    }
    // Primero los puestos concretos (los más difíciles de cubrir).
    usort($out, fn($a, $b) => ($a[1] === null) <=> ($b[1] === null));
    return $out;
}

// Reparte a las personas que trabajan ese día entre las necesidades. $dia: [uid => ['horario_id', 'puesto_id']].
// Devuelve [[horario_id, puesto_id, faltan, [uid asignados]], …].
function cubrir_dia(array $necesidades, array $dia, array $puestos_de): array
{
    $libres = $dia;
    $out = [];
    foreach ($necesidades as [$h, $p, $n]) {
        $asig = [];
        foreach ($libres as $uid => $c) {
            if (count($asig) >= $n) break;
            if ($c['horario_id'] != $h) continue;
            if ($p && $c['puesto_id'] != $p && !($c['puesto_id'] === null && in_array($p, $puestos_de[$uid] ?? [], true))) continue;
            $asig[] = $uid;
            unset($libres[$uid]);
        }
        $out[] = [$h, $p, $n - count($asig), $asig];
    }
    return $out;
}

// Huecos entre $desde y $hasta: [[fecha, horario_id, puesto_id, faltan], …]. Tiene en cuenta bajas y vacaciones aprobadas.
function huecos(PDO $db, array $personas, string $desde, string $hasta): array
{
    return array_values(array_filter(desvios($db, $personas, $desde, $hasta), fn($x) => $x[3] > 0));
}

// El ratio es exacto: [[fecha, horario_id, puesto_id, diferencia], …] con diferencia > 0 si faltan y < 0 si sobran.
function desvios(PDO $db, array $personas, string $desde, string $hasta): array
{
    $pp = puestos_por_persona($db);
    $cals = [];
    foreach ($personas as $u) $cals[$u['id']] = calendario_teorico($db, $u, $desde, $hasta);
    $out = [];
    foreach (rango_fechas($desde, $hasta) as $f) {
        $dia = [];
        foreach ($cals as $uid => $cal) {
            $c = $cal[$f];
            if ($c['horario_id'] && $c['turno'] > 0) $dia[$uid] = ['horario_id' => $c['horario_id'], 'puesto_id' => $c['puesto_id']];
        }
        $nec = necesidades_dia($db, $f);
        $usados = [];
        foreach (cubrir_dia($nec, $dia, $pp) as [$h, $p, $faltan, $asig]) {
            if ($faltan > 0) $out[] = [$f, $h, $p, $faltan];
            foreach ($asig as $uid) $usados[$uid] = true;
        }
        // De más: gente en un turno con ratio que no ha hecho falta para cubrirlo.
        $sobran = [];
        foreach ($dia as $uid => $c) if (!isset($usados[$uid]) && in_array($c['horario_id'], array_column($nec, 0))) $sobran[$c['horario_id']][] = $uid;
        foreach ($sobran as $h => $quienes) $out[] = [$f, $h, null, -count($quienes), $quienes];
    }
    return $out;
}

// Personal de más: para cada persona que sobra en un turno propone pasarla a un hueco (otro día que tenga libre u otro turno
// del mismo día) de su misma familia de turnos (auxiliar, limpieza, coordinación…) sin romper el convenio. Si no hay hueco
// posible, la propuesta es dejarla libre ese día. Devuelve [[fecha, horario_id, uid, fecha destino|null, horario destino|null], …].
function reubicar_sobrantes(PDO $db, array $personas, string $desde, string $hasta): array
{
    $hs = [];
    foreach ($db->query('SELECT id, nombre, departamento_id FROM horarios') as $x) {
        $w = array_values(array_filter(preg_split('/[^a-z]+/', normalizar($x['nombre'])), fn($w) => strlen($w) >= 5));
        $hs[$x['id']] = $x['departamento_id'] ? 'd' . $x['departamento_id'] : substr($w[0] ?? $x['nombre'], 0, 5);
    }
    $dv = desvios($db, $personas, $desde, $hasta);
    $faltas = [];
    foreach ($dv as $x) for ($i = 0; $i < $x[3]; $i++) $faltas[] = [$x[0], $x[1]];
    $por_id = array_column($personas, null, 'id');
    $cal = [];
    $out = [];
    foreach ($dv as $x) {
        if ($x[3] >= 0) continue;
        [$f, $h] = $x;
        foreach ($x[4] as $uid) {
            $u = $por_id[$uid];
            $cal[$uid] ??= calendario_teorico($db, $u, $desde, $hasta);
            $dest = null;
            foreach ($faltas as $i => [$g, $h2]) {
                if (($hs[$h2] ?? 1) !== ($hs[$h] ?? 2)) continue;
                if ($g !== $f && ($cal[$uid][$g]['turno'] > 0 || $cal[$uid][$g]['ausencia'])) continue;
                if (pasar_turno_valido($db, $u, $f, $g, $h2)) { $dest = [$g, $h2]; unset($faltas[$i]); break; }
            }
            $out[] = [$f, $h, $uid, $dest[0] ?? null, $dest[1] ?? null];
        }
    }
    return $out;
}

// ¿Se puede dejar libre a $u el día $f y ponerle el turno $h2 el día $g sin un bloqueo nuevo del convenio? Prueba y deshace.
function pasar_turno_valido(PDO $db, array $u, string $f, ?string $g, ?int $h2): bool
{
    $a = min($f, $g ?? $f);
    $b = date('Y-m-d', strtotime(max($f, $g ?? $f) . ' +1 day'));
    $antes = count(bloqueos(comprobar_plan($db, $u, $a, $b)));
    $propia = !$db->inTransaction();
    $propia ? $db->beginTransaction() : $db->exec('SAVEPOINT mover');
    try {
        pasar_turno($db, (int)$u['id'], $f, $g, $h2);
        return count(bloqueos(comprobar_plan($db, $u, $a, $b))) <= $antes;
    } finally {
        $propia ? $db->rollBack() : $db->exec('ROLLBACK TO SAVEPOINT mover');
    }
}

// Deja libre el día $f y, si hay destino, pone el turno $h2 el día $g (el mismo día = cambio de turno).
function pasar_turno(PDO $db, int $uid, string $f, ?string $g, ?int $h2): void
{
    consulta($db, 'REPLACE INTO planificacion (usuario_id, fecha, horario_id) VALUES (?, ?, NULL)', [$uid, $f]);
    if ($g && $h2) consulta($db, 'REPLACE INTO planificacion (usuario_id, fecha, horario_id) VALUES (?, ?, ?)', [$uid, $g, $h2]);
}

// Propone un cuadrante: [uid => [fecha => ['horario_id', 'puesto_id'] | null (libre)]].
function generar_cuadrante(PDO $db, array $personas, string $desde, string $hasta, ?array $r = null): array
{
    return planificar($db, $personas, $desde, $hasta, ['reglas' => $r])['plan'];
}

// Pesos medidos con un año de residencia (16 auxiliares para 4+3+2 diarios): reparte la carga de la semana (queda gente
// para el domingo) y premia seguir en el mismo turno (bloques de unos 4 días en vez de días sueltos).
const PESO_SEMANA = 32;
const SEGUIR_TURNO = 400;
// Cuánto peor (en coste del reparto) se acepta a alguien para subir la media de calidad de un turno.
const PESO_CALIDAD = 60;
// Hueco que se arregla con más gente (el resto, como un turno sin horas o sin nadie del departamento, no).
const MOTIVO_REGLAS = 'no hay más personas libres sin pasarse de horas, días seguidos o descansos';

// Motor de planificación. Reglas duras: no está de baja/vacaciones, tiene el puesto y es de su departamento, descanso entre
// jornadas, horas de la semana, máximo 5 días seguidos, un domingo libre cada N semanas y las horas anuales del convenio
// (repartidas a lo largo del año para no agotarlas antes de diciembre).
// $o: modo 'justo' (reparte noches, findes y horas) o 'minimo' (llena primero a quien ya trabaja: usa las menos personas),
//     puestos [uid => [pid]] (sustituye a los de la BD), horarios [hid] (solo esos turnos), bloqueados [uid => [fecha => 1]],
//     necesidades [fecha => lista] (caché), reglas.
// Devuelve plan, faltan [[fecha, horario_id, puesto_id, cuántos, motivo]] y min [uid => minutos].
function planificar(PDO $db, array $personas, string $desde, string $hasta, array $o = []): array
{
    $r = $o['reglas'] ?? null ?: reglas($db);
    $h = horarios($db);
    $pp = $o['puestos'] ?? puestos_por_persona($db);
    $minimo = ($o['modo'] ?? 'justo') === 'minimo';
    $completar = !empty($o['completar']);
    // Mantener: el cuadrante que ya hay no se toca; solo se añaden turnos para llegar a los mínimos (p. ej. tras una baja).
    $mantener = !empty($o['mantener']);
    if ($mantener) $completar = false;
    $solo = isset($o['horarios']) ? array_flip($o['horarios']) : null;
    $bloq = $o['bloqueados'] ?? [];
    // Preferencias del trabajador: solo desempatan entre candidatos válidos (nunca saltan una regla ni el ratio).
    $prefs = $o['preferencias'] ?? preferencias_activas($db);
    $calidad = $o['calidad'] ?? null; // [uid => nota de 1 a 5]: solo si quien genera lo marca
    $bajos = [];
    $fechas = rango_fechas($desde, $hasta);
    $nec = [];
    foreach ($fechas as $f) $nec[$f] = array_values(array_filter($o['necesidades'][$f] ?? necesidades_dia($db, $f), fn($x) => $solo === null || isset($solo[$x[0]])));
    // Quién puede hacer cada turno. Cada persona tiene «grupos»: su departamento y sus puestos (nombres sin tildes, espacios
    // ni signos: «AUXILIAR /GEROCULTOR» = «Auxiliar / Gerocultor»). Un turno es del grupo de su departamento; si no tiene,
    // del de quienes lo han hecho en los últimos 4 meses; si nadie lo ha hecho, vale cualquiera. Así cocina, limpieza o
    // enfermería no reciben turnos de auxiliar.
    $clave = fn($t) => preg_replace('/[^a-z0-9]/', '', normalizar((string)$t));
    $ndep = $db->query('SELECT id, nombre FROM departamentos')->fetchAll(PDO::FETCH_KEY_PAIR);
    $npue = $db->query('SELECT id, nombre FROM puestos')->fetchAll(PDO::FETCH_KEY_PAIR);
    $grupos = $nombre_grupo = [];
    foreach ($personas as $u) {
        // El puesto manda: el departamento solo cuenta si la persona no tiene puesto (un médico en «Auxiliares» no hace noches).
        $g = [];
        foreach ($pp[$u['id']] ?? [] as $pid) if (isset($npue[$pid])) $g[$clave($npue[$pid])] = true;
        if (!$g && $u['departamento_id'] && isset($ndep[$u['departamento_id']])) $g[$clave($ndep[$u['departamento_id']])] = true;
        $grupos[$u['id']] = $g;
    }
    foreach ($ndep + $npue as $n) $nombre_grupo[$clave($n)] ??= $n;
    $hecho = [];
    foreach (consulta($db, 'SELECT usuario_id, horario_id, COUNT(*) n FROM planificacion WHERE horario_id IS NOT NULL AND fecha BETWEEN ? AND ? GROUP BY usuario_id, horario_id',
        [date('Y-m-d', strtotime("$desde -120 days")), $desde]) as $x) $hecho[$x['usuario_id']][$x['horario_id']] = (int)$x['n'];
    foreach ($personas as $u) if ($u['horario_id']) $hecho[$u['id']][$u['horario_id']] = ($hecho[$u['id']][$u['horario_id']] ?? 0) + 1000;
    $de_turno = [];
    foreach ($h as $hid => $x) {
        if ($x['departamento_id'] && isset($ndep[$x['departamento_id']])) { $de_turno[$hid] = [$clave($ndep[$x['departamento_id']]) => true]; continue; }
        $de_turno[$hid] = null;
        foreach ($personas as $u) if (isset($hecho[$u['id']][$hid])) $de_turno[$hid] = ($de_turno[$hid] ?? []) + $grupos[$u['id']];
        if ($de_turno[$hid] === []) $de_turno[$hid] = null;
        // Ni departamento ni historial: por el nombre («AUXILIAR MAÑANA» es de «Auxiliar / Gerocultor», «LIMPIEZA TARDE» de «Limpiador»).
        if ($de_turno[$hid] === null) {
            $todos = array_unique(array_merge(array_map($clave, array_values($ndep + $npue)), ...array_values(array_map('array_keys', $grupos))));
            foreach (preg_split('/[^a-z]+/', normalizar($x['nombre'])) as $w) {
                if (strlen($w) < 5 || in_array($w, ['manana', 'tarde', 'noche', 'turno', 'jornada', 'horas', 'refuerzo', 'partido', 'largo', 'intensiva', 'festivo'], true)) continue;
                foreach ($todos as $k) if (strncmp($k, $w, 5) === 0) $de_turno[$hid][$k] = true;
            }
        }
    }
    // Turno con mínimo del que no se sabe nada: lo hace el personal de los demás turnos con mínimo (no cocina ni oficinas).
    $operativos = [];
    foreach ($nec as $l) foreach ($l as [$hid]) if ($de_turno[$hid]) $operativos += $de_turno[$hid];
    // Y lo mismo con los turnos sin dueño (JORNADA 7 HORAS, REFUERZO…): son de ese personal, no de cocina ni oficinas.
    if ($operativos) foreach ($de_turno as $hid => $g) if ($g === null) $de_turno[$hid] = $operativos;
    // Si del grupo del turno no hay nadie (fichas sin departamento), lo hace quien ya lo ha hecho.
    $hay = [];
    // Mismo grupo si coincide el nombre o sus 5 primeras letras («Limpieza» y «Limpiador», «Auxiliar» y «Auxiliar / Gerocultor»).
    $coincide = function (array $a, array $b): bool {
        foreach ($a as $x => $_) foreach ($b as $y => $_) if ($x === $y || strlen($x) >= 5 && strlen($y) >= 5 && strncmp($x, $y, 5) === 0) return true;
        return false;
    };
    foreach ($de_turno as $hid => $g) if ($g) foreach ($personas as $u) if ($coincide($g, $grupos[$u['id']])) { $hay[$hid] = true; break; }
    $vale = fn($u, $hid) => $de_turno[$hid] === null
        || (isset($hay[$hid]) ? $coincide($de_turno[$hid], $grupos[$u['id']]) : isset($hecho[$u['id']][$hid]));
    $turnos_nec = array_unique(array_merge([], ...array_map(fn($l) => array_column($l, 0), array_values($nec))));
    // Turnos con hora fija que puede hacer cada persona al completar su jornada: los de su grupo (no los de «cualquiera»).
    // Un turno de «cualquiera» solo si la persona puede cubrir su necesidad (con el puesto que pida).
    $cubre = [];
    $pares = [];
    foreach ($nec as $l) foreach ($l as [$hid, $pid]) $pares[$hid . ':' . $pid] = [$hid, $pid];
    foreach ($pares as [$hid, $pid]) foreach ($personas as $u) if ((!$pid || in_array($pid, $pp[$u['id']] ?? [], true)) && $vale($u, $hid)) $cubre[$u['id']][$hid] = true;
    // Primero los turnos que menos gente puede hacer (p. ej. el partido, solo coordinación): así no se quedan sin nadie.
    $cuantos_pueden = [];
    foreach ($cubre as $hs) foreach ($hs as $hid => $_) $cuantos_pueden[$hid] = ($cuantos_pueden[$hid] ?? 0) + 1;
    foreach ($nec as &$l) usort($l, fn($a, $b) => [$a[1] === null, $cuantos_pueden[$a[0]] ?? 0] <=> [$b[1] === null, $cuantos_pueden[$b[0]] ?? 0]);
    unset($l);
    $turnos_de = [];
    foreach ($personas as $u) foreach ($h as $hid => $x) {
        if (!$x['activo'] || $x['flexible'] || !$x['dias'] || ($solo !== null && !isset($solo[$hid]))) continue;
        if ($de_turno[$hid] !== null ? $vale($u, $hid) && (!in_array($hid, $turnos_nec) || isset($cubre[$u['id']][$hid])) : isset($cubre[$u['id']][$hid])) $turnos_de[$u['id']][] = $hid;
    }
    // Entra quien puede cubrir una necesidad o, al completar jornada, quien tiene turnos de su grupo (p. ej. limpieza).
    // Al resto (sin turnos que le encajen) no se le toca su horario.
    $personas = array_values(array_filter($personas, fn($u) => !empty($cubre[$u['id']]) || $completar && !empty($turnos_de[$u['id']])));
    // Horas anuales (prorrateadas al periodo) y ritmo: a mitad de sus días disponibles, como mucho la mitad + 24 h.
    $tope = $r['horas_anuales'] ? $r['horas_anuales'] * 60 * count($fechas) / 365 : null;
    // Completar jornada: objetivo del periodo (horas anuales prorrateadas o la media semanal).
    $objetivo = min($tope ?? PHP_INT_MAX, $r['horas_semana_media'] * 60 * count($fechas) / 7);
    $ant = date('Y-m-d', strtotime("$desde -7 days"));
    $estado = [];
    foreach ($personas as $u) {
        $uid = (int)$u['id'];
        $tras = date('Y-m-d', strtotime("$hasta +1 day"));
        $cal = calendario_teorico($db, $u, $ant, $tras);
        // Lo que ya tiene el día siguiente al periodo: el último día tiene que dejarle sus horas de descanso.
        $ct = $cal[$tras];
        $ini_tras = $ct['turno'] && $ct['entrada'] && !$ct['flexible'] ? ts_local($tras, $ct['entrada']) : 0;
        unset($cal[$tras]);
        $pasado = array_filter($cal, fn($f) => $f < $desde, ARRAY_FILTER_USE_KEY);
        $iv = intervalos_plan($pasado);
        $seguidos = 0;
        foreach (array_reverse($pasado) as $c) {
            if (!$c['turno']) break;
            $seguidos++;
        }
        // Días en que puede trabajar (sin vacaciones ni bajas): el ritmo de horas se reparte sobre ellos, así quien vuelve de vacaciones recupera.
        $disp = [];
        $k = 0;
        // Antes del alta o después de la baja no puede trabajar: se trata como un día bloqueado.
        $alta = local($u['alta_utc'] ?? '2000-01-01 00:00:00', 'Y-m-d');
        $baja = !empty($u['baja_utc']) ? local($u['baja_utc'], 'Y-m-d') : '9999-12-31';
        foreach ($fechas as $f) if ($f < $alta || $f > $baja) $bloq[$uid][$f] = 1;
        foreach ($fechas as $f) $disp[$f] = $k += (isset($bloq[$uid][$f]) || ($cal[$f]['ausencia'] && $cal[$f]['ausencia']['minutos'] === null)) ? 0 : 1;
        $ultimo = null;
        foreach ($pasado as $c) if ($c['horario_id'] && $c['turno']) $ultimo = (int)$c['horario_id'];
        $estado[$uid] = ['fin' => $iv ? end($iv)[2] : 0, 'seguidos' => $seguidos, 'min' => 0, 'finde' => 0, 'noches' => 0, 'semana' => [], 'cal' => $cal, 'domingos' => 0,
            'disp' => $disp, 'disp_total' => max(1, $k), 'ultimo' => $ultimo, 'u' => $u, 'fin0' => $iv ? end($iv)[2] : 0, 'seguidos0' => $seguidos, 'ini_tras' => $ini_tras];
    }
    // Datos de un turno en una fecha: [minutos, inicio, fin, noche] o el motivo por el que no se puede usar.
    $datos = function (int $hid, string $f) use ($h, $r) {
        $d = $h[$hid]['dias'][(int)date('N', strtotime($f))] ?? ($h[$hid]['dias'] ? reset($h[$hid]['dias']) : null);
        if (!$d || !$d['entrada'] || !$d['salida']) return 'el turno no tiene hora de entrada y salida';
        if ($d['minutos'] > $r['jornada_max_diaria_h'] * 60) return 'el turno dura más que la jornada máxima diaria';
        $ini = ts_local($f, $d['entrada']);
        $fin = ts_local($f, $d['salida']);
        if ($fin <= $ini) $fin += 86400;
        return [$d['minutos'], $ini, $fin, (int)substr($d['entrada'], 0, 2) >= 20 || (int)substr($d['salida'], 0, 2) <= 7 && $fin - $ini > 3600];
    };
    // Por qué no se cubre un turno: nadie puede hacerlo nunca (falta gente en el departamento o con el puesto) o las reglas no dan.
    $motivo = function (int $hid, ?int $pid) use ($personas, $pp, $vale, $h, $db) {
        foreach ($personas as $u) if ($vale($u, $hid) && (!$pid || in_array($pid, $pp[$u['id']] ?? [], true))) return MOTIVO_REGLAS;
        $dep = $h[$hid]['departamento_id'] ? consulta($db, 'SELECT nombre FROM departamentos WHERE id = ?', [$h[$hid]['departamento_id']])->fetchColumn() : 'el de quienes lo hacen';
        return $pid ? 'nadie tiene ese puesto asignado en su ficha'
            : 'nadie del departamento «' . $dep . '»: pon ese departamento en la ficha de quien hace este turno';
    };
    // Turnos que ya tiene cada persona (modo mantener): cuentan para sus horas, su semana y los mínimos.
    $fijo = [];
    if ($mantener) foreach ($estado as $uid => $e) foreach ($fechas as $f) {
        $c = $e['cal'][$f];
        if (!$c['turno'] || !$c['horario_id'] || isset($bloq[$uid][$f]) || ($c['ausencia'] && $c['ausencia']['minutos'] === null) || !is_array($t = $datos((int)$c['horario_id'], $f))) continue;
        $fijo[$uid][$f] = [(int)$c['horario_id'], $c['puesto_id'] ? (int)$c['puesto_id'] : null, $t];
        $estado[$uid]['min'] += $t[0];
        $estado[$uid]['semana'][date('o-W', strtotime($f))] = ($estado[$uid]['semana'][date('o-W', strtotime($f))] ?? 0) + $t[0];
    }
    $nuevos = [];
    $plan = $faltan = [];
    foreach ($fechas as $i => $f) {
        $semana = date('o-W', strtotime($f));
        $dom = date('N', strtotime($f)) == 7;
        $finde = date('N', strtotime($f)) >= 6 || $estado && reset($estado)['cal'][$f]['festivo'];
        $hoy = [];
        // Reglas duras para una persona y un turno ese día.
        $puede = function (int $uid, int $hid, ?int $pid, array $t) use (&$estado, &$hoy, $bloq, $pp, $vale, $f, $semana, $dom, $r, $tope, $hasta, $fijo) {
            $e = $estado[$uid];
            $c = $e['cal'][$f];
            [$m, $ini] = $t;
            if (isset($hoy[$uid]) || isset($bloq[$uid][$f]) || ($c['ausencia'] && $c['ausencia']['minutos'] === null)) return false;
            if ($pid && !in_array($pid, $pp[$uid] ?? [], true)) return false;
            if (!$vale($e['u'], $hid)) return false;
            if ($e['fin'] && $ini - $e['fin'] < $r['descanso_entre_jornadas_h'] * 3600) return false;
            if ($e['ini_tras'] && $f === $hasta && $e['ini_tras'] - $t[2] < $r['descanso_entre_jornadas_h'] * 3600) return false;
            if (($e['semana'][$semana] ?? 0) + $m > $r['horas_semana_media'] * 60) return false;
            if ($e['seguidos'] >= 5) return false;
            if ($fijo) {
                // Lo que ya tiene después: descanso hasta su siguiente turno y días seguidos que sumaría.
                $sig = date('Y-m-d', strtotime("$f +1 day"));
                if (isset($fijo[$uid][$sig]) && $fijo[$uid][$sig][2][1] - $t[2] < $r['descanso_entre_jornadas_h'] * 3600) return false;
                $mas = 0;
                for ($g = $sig; isset($fijo[$uid][$g]); $g = date('Y-m-d', strtotime("$g +1 day"))) $mas++;
                if ($e['seguidos'] + 1 + $mas > 5) return false;
            }
            if ($dom && $r['domingo_cada_semanas'] && $e['domingos'] >= $r['domingo_cada_semanas'] - 1) return false;
            if ($tope && ($e['min'] + $m > $tope || !$fijo && $e['min'] + $m > $tope * $e['disp'][$f] / $e['disp_total'] + 24 * 60)) return false;
            return true;
        };
        $asignar = function (int $uid, int $hid, ?int $pid, array $t) use (&$estado, &$hoy, &$plan, $f, $semana, $finde) {
            [$m, , $fin, $noche] = $t;
            $hoy[$uid] = true;
            $plan[$uid][$f] = ['horario_id' => $hid, 'puesto_id' => $pid];
            $estado[$uid]['fin'] = $fin;
            $estado[$uid]['min'] += $m;
            $estado[$uid]['semana'][$semana] = ($estado[$uid]['semana'][$semana] ?? 0) + $m;
            $estado[$uid]['finde'] += $finde ? 1 : 0;
            $estado[$uid]['noches'] += $noche ? 1 : 0;
            $estado[$uid]['ultimo'] = $hid;
        };
        // Los que ya trabajan hoy (modo mantener) se ponen primero y cubren su parte de los mínimos.
        $libres_fijos = [];
        foreach ($fijo as $uid => $dias) if (isset($dias[$f])) {
            [$hid, $pid, $t] = $dias[$f];
            $hoy[$uid] = true;
            $plan[$uid][$f] = ['horario_id' => $hid, 'puesto_id' => $pid];
            $estado[$uid]['fin_ayer'] = $estado[$uid]['fin'];
            $estado[$uid]['fin'] = $t[2];
            $estado[$uid]['finde'] += $finde ? 1 : 0;
            $estado[$uid]['noches'] += $t[3] ? 1 : 0;
            $estado[$uid]['ultimo'] = $hid;
            $libres_fijos[$uid] = [$hid, $pid];
        }
        // Lo que sobra hoy en cada turno (gente de más sobre su mínimo, o turnos sin mínimo): de ahí se puede cambiar a alguien.
        $sobra = [];
        foreach ($libres_fijos as [$fh]) $sobra[$fh] = ($sobra[$fh] ?? 0) + 1;
        foreach ($nec[$f] as [$nh, , $nn]) if (isset($sobra[$nh])) $sobra[$nh] -= $nn;
        $cuantos = [];
        foreach ($nec[$f] as [$hid, $pid, $n]) {
            foreach ($libres_fijos as $uid => [$fh, $fp]) {
                if ($n <= 0) break;
                if ($fh != $hid || ($pid && $fp != $pid && !($fp === null && in_array($pid, $pp[$uid] ?? [], true)))) continue;
                $n--;
                unset($libres_fijos[$uid]);
            }
            if ($n <= 0) continue;
            $t = $datos($hid, $f);
            if (is_string($t)) {
                $faltan[] = [$f, $hid, $pid, $n, $t];
                continue;
            }
            $cand = [];
            foreach ($personas as $u) {
                $uid = (int)$u['id'];
                if (!$puede($uid, $hid, $pid, $t)) continue;
                $e = $estado[$uid];
                $ayer = ($plan[$uid][date('Y-m-d', strtotime("$f -1 day"))]['horario_id'] ?? null) == $hid ? SEGUIR_TURNO : 0;
                // Justo: menos es mejor (horas, findes y noches acumuladas). Mínimo: primero quien ya trabaja más.
                $cand[$uid] = $minimo ? -$e['min'] / 60 - $ayer + $uid / 1e6
                    : $e['min'] / 60 + ($finde ? 8 * $e['finde'] : 0) + ($t[3] ? 8 * $e['noches'] : 0) - $ayer + $uid / 1e6
                    // Quien ya lleva más horas esta semana, después: así queda gente libre para el domingo.
                    + PESO_SEMANA * ($e['semana'][$semana] ?? 0) / 60;
                if (!empty($prefs[$uid])) $cand[$uid] += ajuste_preferencias($prefs[$uid], $f, $hid);
            }
            asort($cand);
            $elegidos = array_slice(array_keys($cand), 0, $n);
            // Calidad (privada): en turnos que no son de noche, si la media de los elegidos baja de 3, se cambia al peor por el
            // siguiente candidato que la mejore, si su coste es parecido. Nunca rompe ratios ni reglas: solo elige entre los que valen.
            if ($calidad && !$t[3] && $n > 1) {
                $q = fn($x) => $calidad[$x] ?? 3.0;
                $resto = array_slice(array_keys($cand), $n, 8);
                while (count($elegidos) === $n && array_sum(array_map($q, $elegidos)) / $n < 3 && $resto) {
                    usort($elegidos, fn($x, $y) => $q($x) <=> $q($y));
                    $mejor = null;
                    foreach ($resto as $i => $x) if ($q($x) > $q($elegidos[0]) && $cand[$x] - $cand[$elegidos[0]] <= PESO_CALIDAD) { $mejor = $i; break; }
                    if ($mejor === null) break;
                    $elegidos[0] = $resto[$mejor];
                    unset($resto[$mejor]);
                }
                if (count($elegidos) === $n && ($m = array_sum(array_map($q, $elegidos)) / $n) < 3) $bajos[] = [$f, $hid, round($m, 1)];
            }
            // Mantener: si no hay nadie libre, se cambia de turno a quien hoy está donde sobra gente (mismas horas, con sus descansos).
            if ($fijo && count($elegidos) < $n) foreach ($libres_fijos as $uid => [$fh, $fp]) {
                if (count($elegidos) >= $n) break;
                if ($fh == $hid || ($sobra[$fh] ?? 0) <= 0 || !$vale($estado[$uid]['u'], $hid) || ($pid && !in_array($pid, $pp[$uid] ?? [], true))) continue;
                $e = $estado[$uid];
                $viejo = $fijo[$uid][$f][2];
                $sig = date('Y-m-d', strtotime("$f +1 day"));
                if ($e['fin_ayer'] && $t[1] - $e['fin_ayer'] < $r['descanso_entre_jornadas_h'] * 3600) continue;
                if (isset($fijo[$uid][$sig]) && $fijo[$uid][$sig][2][1] - $t[2] < $r['descanso_entre_jornadas_h'] * 3600) continue;
                if ($f === $hasta && $e['ini_tras'] && $e['ini_tras'] - $t[2] < $r['descanso_entre_jornadas_h'] * 3600) continue;
                if (($e['semana'][$semana] ?? 0) - $viejo[0] + $t[0] > $r['horas_semana_media'] * 60) continue;
                $plan[$uid][$f] = ['horario_id' => $hid, 'puesto_id' => $pid];
                $estado[$uid]['fin'] = $t[2];
                $estado[$uid]['min'] += $t[0] - $viejo[0];
                $estado[$uid]['semana'][$semana] += $t[0] - $viejo[0];
                $nuevos[] = [$uid, $f, $hid, $pid];
                $sobra[$fh]--;
                unset($libres_fijos[$uid]);
                $n--;
            }
            if (count($elegidos) < $n) $faltan[] = [$f, $hid, $pid, $n - count($elegidos), $motivo($hid, $pid)];
            foreach ($elegidos as $uid) {
                $asignar($uid, $hid, $pid, $t);
                $nuevos[] = [$uid, $f, $hid, $pid];
            }
            $cuantos[$hid] = ($cuantos[$hid] ?? 0) + count($elegidos);
        }
        foreach ($personas as $u) {
            $uid = (int)$u['id'];
            if ($dom) $estado[$uid]['domingos'] = isset($hoy[$uid]) ? $estado[$uid]['domingos'] + 1 : 0;
            if (isset($hoy[$uid])) $estado[$uid]['seguidos']++;
            else {
                $estado[$uid]['seguidos'] = 0;
                $plan[$uid][$f] = null;
            }
        }
    }
    // Completar jornada (después de cubrir las necesidades de todo el periodo, para no gastar horas que harán falta):
    // en los días libres, quien no llega a sus horas trabaja en el turno de al lado, su último o su habitual.
    if ($completar) {
        // Por referencia: tiene que ver también los turnos que se van poniendo al completar.
        $mins = function ($uid, $f) use (&$plan, $datos) {
            $x = $plan[$uid][$f] ?? null;
            return $x && is_array($t = $datos($x['horario_id'], $f)) ? $t : null;
        };
        $ayer = fn($f, $n) => date('Y-m-d', strtotime("$f $n day"));
        $datos_min = fn($hid) => $h[$hid]['dias'] ? (int)reset($h[$hid]['dias'])['minutos'] : 0;
        $wk = fn($f) => date('o-W', strtotime($f));
        $sem = [];
        foreach ($plan as $uid => $dias) foreach ($dias as $g => $x) if ($x && ($t = $mins($uid, $g))) $sem[$uid][$wk($g)] = ($sem[$uid][$wk($g)] ?? 0) + $t[0];
        $semanas = [];
        foreach ($fechas as $f) $semanas[$wk($f)][] = $f;
        $gk = array_map(fn($g) => (string)array_key_first($g), $grupos);
        // Pone un turno a $uid el día $f si cabe con todas las reglas. Devuelve si lo ha puesto.
        $intentar = function (int $uid, string $f, int $obj_w) use (&$plan, &$estado, &$sem, $mins, $ayer, $datos, $datos_min, $wk, $bloq, $desde, $hasta, $objetivo, $r, $turnos_de, $turnos_nec, $hecho, $h) {
            $e = $estado[$uid];
            $c = $e['cal'][$f];
            if (!array_key_exists($f, $plan[$uid] ?? []) || $plan[$uid][$f] || isset($bloq[$uid][$f]) || ($c['ausencia'] && $c['ausencia']['minutos'] === null)) return false;
            // Días seguidos que quedarían (antes y después).
            $racha = 1;
            for ($k = -1; ($g = $ayer($f, $k)) >= $desde ? !empty($plan[$uid][$g]) : false; $k--) $racha++;
            if ($ayer($f, $k) < $desde) $racha += $e['seguidos0'];
            for ($k = 1; !empty($plan[$uid][$ayer($f, $k)]); $k++) $racha++;
            if ($racha > 5) return false;
            $previo = $mins($uid, $ayer($f, -1));
            $fin_previo = $previo ? $previo[2] : ($ayer($f, -1) < $desde ? $e['fin0'] : 0);
            $sig = $mins($uid, $ayer($f, 1));
            $w = $wk($f);
            // Orden: el del día de al lado (bloques), su habitual y los que más ha hecho, los que tienen mínimo y el resto de su grupo (los largos antes).
            // Todos sus turnos; los cortos (refuerzos de menos de 7 h) solo para cerrar lo que le falta o si ya los hace: no se trocea la jornada.
            $resto = min($objetivo - $e['min'], $obj_w - ($sem[$uid][$w] ?? 0));
            $suyos = array_values(array_filter($turnos_de[$uid] ?? [], fn($x) => $datos_min($x) >= 420 || $resto < 420 || isset($hecho[$uid][$x])));
            usort($suyos, fn($x, $y) => [-($hecho[$uid][$x] ?? 0), !in_array($x, $turnos_nec), -$datos_min($x)] <=> [-($hecho[$uid][$y] ?? 0), !in_array($y, $turnos_nec), -$datos_min($y)]);
            $opciones = array_unique(array_filter([$plan[$uid][$ayer($f, -1)]['horario_id'] ?? null, $plan[$uid][$ayer($f, 1)]['horario_id'] ?? null, ...$suyos],
                fn($x) => $x && isset($h[$x]) && in_array($x, $suyos)));
            foreach ($opciones as $hid) {
                $t = $datos($hid, $f);
                // Horas del periodo y de esta semana (su parte según los días que puede trabajar): no se gastan al principio.
                if (is_string($t) || $e['min'] + $t[0] / 2 > $objetivo || ($sem[$uid][$w] ?? 0) + $t[0] / 2 > $obj_w) continue;
                if ($fin_previo && $t[1] - $fin_previo < $r['descanso_entre_jornadas_h'] * 3600) continue;
                if ($sig && $sig[1] - $t[2] < $r['descanso_entre_jornadas_h'] * 3600) continue;
                if ($f === $hasta && $e['ini_tras'] && $e['ini_tras'] - $t[2] < $r['descanso_entre_jornadas_h'] * 3600) continue;
                if (($sem[$uid][$w] ?? 0) + $t[0] > $r['horas_semana_media'] * 60) continue;
                $plan[$uid][$f] = ['horario_id' => $hid, 'puesto_id' => null];
                $estado[$uid]['min'] += $t[0];
                $sem[$uid][$w] = ($sem[$uid][$w] ?? 0) + $t[0];
                $estado[$uid]['finde'] += date('N', strtotime($f)) >= 6 ? 1 : 0;
                $estado[$uid]['noches'] += $t[3] ? 1 : 0;
                return true;
            }
            return false;
        };
        // Semana a semana, por rondas: cada persona que va por detrás recibe un día más, el día de la semana con menos gente de su
        // grupo. Así la plantilla queda repartida entre todos los días (no 40 el lunes y 13 el miércoles).
        foreach ($semanas as $w => $dias) {
            $obj = [];
            foreach ($estado as $uid => $e) {
                $libres = 0;
                foreach ($dias as $f) $libres += $e['disp'][$f] - ($e['disp'][$ayer($f, -1)] ?? 0);
                $obj[$uid] = (int)round($objetivo * $libres / $e['disp_total']);
            }
            $usables = array_values(array_filter($dias, fn($f) => !(date('N', strtotime($f)) == 7 && $r['domingo_cada_semanas'])));
            do {
                $puesto = false;
                $cont = [];
                foreach ($dias as $f) foreach ($estado as $uid => $e) if (!empty($plan[$uid][$f])) $cont[$f][$gk[$uid]] = ($cont[$f][$gk[$uid]] ?? 0) + 1;
                $orden = array_filter(array_keys($estado), fn($uid) => ($sem[$uid][$w] ?? 0) + 210 <= $obj[$uid] && $estado[$uid]['min'] + 210 <= $objetivo);
                usort($orden, fn($x, $y) => [($sem[$x][$w] ?? 0) - $obj[$x], $x] <=> [($sem[$y][$w] ?? 0) - $obj[$y], $y]);
                foreach ($orden as $uid) {
                    $ds = $usables;
                    usort($ds, fn($x, $y) => [$cont[$x][$gk[$uid]] ?? 0, $x] <=> [$cont[$y][$gk[$uid]] ?? 0, $y]);
                    foreach ($ds as $f) if ($intentar($uid, $f, $obj[$uid])) {
                        $puesto = true;
                        $cont[$f][$gk[$uid]] = ($cont[$f][$gk[$uid]] ?? 0) + 1;
                        break;
                    }
                }
            } while ($puesto);
        }
        ksort($estado);
    }
    $quien = [];
    foreach ($turnos_nec as $hid) $quien[$hid] = $de_turno[$hid] === null ? 'cualquiera' : implode(', ', array_map(fn($k) => $nombre_grupo[$k] ?? $k, array_keys($de_turno[$hid])));
    return ['plan' => $plan, 'calidad_baja' => $bajos, 'faltan' => $faltan, 'quien' => $quien, 'nuevos' => $nuevos, 'min' => array_map(fn($e) => $e['min'], $estado),
        'noches' => array_map(fn($e) => $e['noches'], $estado), 'findes' => array_map(fn($e) => $e['finde'], $estado)];
}

// Tras una baja, vacaciones o excedencia: mantiene el cuadrante de todos y añade los turnos que faltan para llegar a los
// mínimos (con las mismas reglas). Guarda, avisa a quien entra y devuelve ['nuevos' => [[uid, fecha, horario]], 'faltan' => …].
function recubrir(PDO $db, string $desde, string $hasta, ?int $autor = null): array
{
    $desde = max($desde, local(ahora(), 'Y-m-d'));
    if ($hasta < $desde) return ['nuevos' => [], 'faltan' => []];
    $personas = $db->query("SELECT * FROM usuarios WHERE activo = 1 AND rol IN ('empleado','responsable','admin')")->fetchAll();
    $r = planificar($db, $personas, $desde, $hasta, ['mantener' => true]);
    $h = horarios($db);
    foreach ($r['nuevos'] as [$uid, $f, $hid, $pid]) {
        consulta($db, 'REPLACE INTO planificacion (usuario_id, fecha, horario_id, puesto_id) VALUES (?, ?, ?, ?)', [$uid, $f, $hid, $pid]);
        notificar($db, (int)$uid, "recubrir:$uid:$f", 'Se te ha asignado ' . $h[$hid]['nombre'] . ' el ' . date('d/m', strtotime($f)) . ' para cubrir el mínimo de personal.', 'calendario');
    }
    if ($autor) auditar($db, $autor, 'cuadrante_recalculado', "$desde..$hasta nuevos=" . count($r['nuevos']));
    return ['nuevos' => $r['nuevos'], 'faltan' => $r['faltan']];
}

// Escribe un cuadrante (de generar_cuadrante) en la planificación. Las ausencias aprobadas se respetan solas.
function guardar_cuadrante(PDO $db, array $plan): void
{
    foreach ($plan as $uid => $dias) {
        foreach ($dias as $f => $x) {
            consulta($db, 'REPLACE INTO planificacion (usuario_id, fecha, horario_id, puesto_id) VALUES (?, ?, ?, ?)', [$uid, $f, $x['horario_id'] ?? null, $x['puesto_id'] ?? null]);
        }
    }
}

// Ratios de AS FRAGAS (capturas de su configuración anterior): turno => mínimo de personas.
// Ratios exactos de AS FRAGAS (ni uno más ni uno menos): turno => personas.
const RATIOS_RESIDENCIA = ['RATIO AUXILIARES MAÑANA' => ['AUXILIAR MAÑANA', 4], 'RATIO AUXILIARES TARDE' => ['AUXILIAR TARDE', 3], 'RATIO AUXILIARES NOCHE' => ['AUXILIAR NOCHE', 2],
    'RATIO PARTIDO' => ['COORDINACIÓN PARTIDO', 2], 'RATIO LIMPIEZA MAÑANA' => ['LIMPIEZA MAÑANA', 1], 'RATIO LIMPIEZA TARDE' => ['LIMPIEZA TARDE', 1]];

// Crea las reglas cuyo turno ya existe (por nombre, sin importar mayúsculas ni tildes). Devuelve [creadas, turnos que faltan].
function cargar_ratios(PDO $db, array $ratios = RATIOS_RESIDENCIA): array
{
    $hors = [];
    foreach ($db->query('SELECT id, nombre FROM horarios WHERE activo = 1') as $h) $hors[normalizar($h['nombre'])] = (int)$h['id'];
    $creadas = $faltan = [];
    foreach ($ratios as $nombre => [$turno, $min]) {
        $hid = $hors[normalizar($turno)] ?? null;
        if (!$hid) { $faltan[] = $turno; continue; }
        if (consulta($db, 'SELECT 1 FROM necesidades WHERE nombre = ?', [$nombre])->fetchColumn()) continue;
        consulta($db, 'INSERT INTO necesidades (nombre, horario_id, puesto_id, dia, personas) VALUES (?, ?, NULL, 0, ?)', [$nombre, $hid, $min]);
        $creadas[] = $nombre;
    }
    return [$creadas, $faltan];
}

// Cron: si hoy o mañana no se llega al ratio (bajas, vacaciones…), avisa a administración una vez por día y turno.
function revisar_ratios(PDO $db, ?string $ahora = null): int
{
    $ahora ??= ahora();
    $personas = $db->query("SELECT * FROM usuarios WHERE activo = 1 AND rol IN ('empleado','responsable','admin')")->fetchAll();
    if (!$personas || !$db->query('SELECT 1 FROM necesidades WHERE activo = 1 LIMIT 1')->fetchColumn()) return 0;
    $hoy = local($ahora, 'Y-m-d');
    $manana = date('Y-m-d', strtotime("$hoy +1 day"));
    $hors = horarios($db);
    $pn = puestos($db);
    $admins = array_map('intval', $db->query("SELECT id FROM usuarios WHERE rol = 'admin' AND activo = 1")->fetchAll(PDO::FETCH_COLUMN));
    $n = 0;
    $lineas = [];
    foreach (desvios($db, $personas, $hoy, $manana) as [$f, $h, $p, $faltan]) {
        $txt = ($f === $hoy ? 'Hoy' : 'Mañana') . ($faltan > 0 ? ' faltan ' . $faltan : ' sobran ' . -$faltan) . ' en ' . ($hors[$h]['nombre'] ?? 'turno') . ($p ? ' (' . ($pn[$p] ?? '') . ')' : '') . ' para cumplir el ratio.';
        $nuevo = false;
        foreach ($admins as $a) $nuevo = notificar($db, $a, "ratio:$f:$h:" . ($p ?? '') . ":$faltan", $txt, 'planificacion&semana=' . $f) || $nuevo;
        if ($nuevo) { $n++; $lineas[] = $txt; }
    }
    if ($lineas) avisar_administracion('INDA: hay turnos que no cumplen el ratio', implode("\n", $lineas) . "\n\n" . rtrim(config()['url'] ?? '', '/') . '/?p=planificacion');
    return $n;
}

// Presencia orientativa (no obligatoria): por cada regla activa y día, cuántas personas de ese puesto trabajan.
// Devuelve [[fecha, nombre, hay, referencia, [nombres]], …] (todos los días, cumplan o no).
function presencia_orientativa(PDO $db, string $desde, string $hasta): array
{
    $out = [];
    foreach ($db->query('SELECT * FROM presencias WHERE activo = 1 ORDER BY nombre') as $r) {
        $gente = consulta($db, 'SELECT u.* FROM usuarios u JOIN usuarios_puestos up ON up.usuario_id = u.id WHERE up.puesto_id = ? AND u.activo = 1', [$r['puesto_id']])->fetchAll();
        $cals = array_map(fn($u) => calendario_teorico($db, $u, $desde, $hasta), $gente);
        foreach (rango_fechas($desde, $hasta) as $f) {
            $quien = [];
            foreach ($gente as $i => $u) if ($cals[$i][$f]['turno'] > 0 && !$cals[$i][$f]['ausencia']) $quien[] = nombre($u);
            $out[] = [$f, $r['nombre'], count($quien), (int)$r['personas'], $quien];
        }
    }
    return $out;
}
